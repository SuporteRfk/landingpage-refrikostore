import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { useRef, useState } from "react";
import { FaMapMarkedAlt as IconMap } from "react-icons/fa";
import IconCatalog from "../assets/catalogo.webp";

const Description = () => {
  // useRef cria uma referência para a seção que queremos observar o scroll.
  // Essa referência é usada para vincular o comportamento da barra ao elemento correto.  
  const sectionRef = useRef(null); 

  // Estado para controlar a altura da barra.
  // `barHeight` começa com 0 e é atualizado dinamicamente com base no progresso do scroll.
  const [barHeight, setBarHeight] = useState(0); 
  const maxProgress = 0.95;  // Limite máximo de progresso da barra (95% para criar a margem de 40px do final da sessão).

  // Hook `useScroll` do Framer Motion:
  // Monitora o progresso do scroll dentro do elemento referenciado.
  const { scrollYProgress } = useScroll({
    target: sectionRef, // Observa o progresso apenas dentro do `sectionRef`.
    offset: ["start end", "end start"], // Define quando o scroll começa e termina:
    // "start end" significa: quando o topo da seção tocar a base da viewport.
    // "end start" significa: quando o final da seção tocar o topo da viewport.
  });

  // Hook `useMotionValueEvent`:
  // Escuta mudanças no valor do `scrollYProgress` e executa ações com base nele.
  useMotionValueEvent(scrollYProgress, "change", (progress) => {
    // Calcula a altura da barra com base no progresso.
    // `Math.min` limita a altura máxima ao valor definido por `maxProgress`.
    const newHeight = Math.min(progress * 100, maxProgress * 100); // Limita a altura ao máximo permitido

    // `Math.max` garante que a barra só cresça, nunca diminua.
    setBarHeight((prevHeight) => Math.max(prevHeight, newHeight)); // Garante que a barra só aumente
  });


   const cards = [
    { id: 1, side: "left", content: "Faça seus pedidos diretamente do celular, sem precisar ir até a recepção. Praticidade para você!" ,title: "Pedidos Onde Você Estiver", icon: IconCatalog},
    { id: 2, side: "right", content: "Tenha acesso a todos os produtos fabricados pela Refriko diretamente no seu smartphone." ,title: "Acesso Completo a Todos os Produtos", icon: IconCatalog},
    { id: 3, side: "left", content: "O app é exclusivo para você, colaborador da Refriko. Garantimos a privacidade e segurança dos seus pedidos." ,title: "Exclusivo para Funcionários", icon: IconCatalog},
    { id: 4, side: "right", content: "Realize seu pedido em poucos cliques, economizando tempo e agilizando sua rotina." ,title: "Rápido e Sem Complicação", icon: IconCatalog},
  ];

  return (
    <section
      ref={sectionRef}
      className="h-[120vh] bg-primary bg-description bg-blend-multiply overflow-hidden flex flex-col"
    >
      {/* Título */}
      <div className="w-full max-w-container mx-auto p-4 flex flex-col items-center justify-center">
        <motion.h1
          initial={{ opacity: 0, scale: 0 }}
          transition={{ duration: 1 }}
          whileInView={{ opacity: 1, scale: 1 }}
          className="text-accent font-bold mt-9 text-3xl lg:text-4xl text-center md:text-5xl"
          viewport={{ once: true }}
        >
          Facilidade na Palma da Sua Mão
        </motion.h1>
        <motion.span
          initial={{ opacity: 0, scale: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          whileInView={{ opacity: 1, scale: 1 }}
          className="font-medium text-center text-lg lg:text-2xl "
          viewport={{ once: true }}
        >
          Descubra como o app exclusivo facilita sua rotina e economiza seu tempo.
        </motion.span>
      </div>

      {/* Cards e barra */}
      <div className="flex flex-col items-center relative max-w-container mx-auto h-screen max-h-full">
        {/* Barra vertical animada */}
        <motion.div
          className="absolute w-2 bg-accent top-0 rounded-lg shadow-lg shadow-white"
          style={{ height: `${barHeight}%` }} // Altura controlada dinamicamente
        />

         {/* Cards */}
        <div className="max-w-container mx-auto flex flex-col gap-4 relative">
            {cards.map((card) => (
            <motion.div
                key={card.id}
                // className={`absolute w-full h-40 p-4 bg-white border border-black rounded-lg shadow-lg ${
                // card.side === "left" ? "left-[-300px]" : "right-[-300px]"
                // }`}
                className={`
                    w-full h-40 bg-secundary rounded-2xl p-4 border-2 border-accent
                    flex flex-col items-center justify-center gap-2
                `}
                initial={{ opacity: 0, x: card.side === "left" ? -100 : 100 }} // Fora do viewport
                whileInView={{ opacity: 1, x: 0 }} // Animação ao entrar na viewport
                transition={{ duration: 0.5 }}
                viewport={{ once: true, amount: 0.5 }} // Ativa quando 50% do card está visível
                style={{
                    top: `${card.id * 20}vh`, // Posição vertical dinâmica
                }}
            >
                <h4>{card.title}</h4>
                <img className="object-cover h-full "src={card.icon} alt="" />
                <p>{card.content}</p>
            </motion.div>
            ))}
        </div>
      </div>
    </section>
  );
};

export { Description };
